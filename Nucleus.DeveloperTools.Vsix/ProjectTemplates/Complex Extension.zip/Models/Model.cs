﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nucleus.Abstractions.Models;

namespace $nucleus.extension.namespace$.Models
{
	public class $nucleus.extension.model_class_name$ : ModelBase
	{
		public Guid Id { get; set; }				
	}
}
